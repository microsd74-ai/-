using System.Net;
using System.Net.Sockets;
using System.Text;
using UopWork.Core;

static void Check(bool ok,string message){if(!ok)throw new Exception(message);}
static void Reject(Action action,string message){try{action();}catch(Exception e) when(e is ArgumentException or IOException or InvalidOperationException or FormatException){return;}throw new Exception(message);}
var root=Path.Combine(Path.GetTempPath(),"uop-checks-"+Guid.NewGuid());Directory.CreateDirectory(root);
try
{
    var store=new SettingsStore(Path.Combine(root,"settings.json"));
    var config=new PrinterConfig(Guid.NewGuid(),"Принтер PMMA","192.168.1.101");
    store.Save(new("Terminal",[config]));var read=store.Load();
    Check(read.Theme=="Terminal" && read.Printers[0].Name==config.Name,"settings roundtrip");
    var before=File.ReadAllText(store.Path);
    Reject(()=>store.Save(new("Dark",[config,config with{Id=Guid.NewGuid()}])),"duplicate accepted");
    Reject(()=>store.Save(new("Dark",[config with{Host="300.0.0.1"}])),"invalid IP accepted");
    Check(File.ReadAllText(store.Path)==before,"invalid save changed file");
    var legacy=Path.Combine(root,"legacy.json");File.WriteAllText(legacy,"{\"printers\":[{\"name\":\"FHZL PMMA\",\"host\":\"192.168.1.101\",\"port\":5055}]}");
    Check(SettingsStore.ImportLazarus(legacy).Single().Name=="FHZL PMMA","legacy import failed");
    Console.WriteLine("PASS settings: UTF-8, themes, validation, duplicate rejection, file preservation, Lazarus import");
    var password=new PasswordStore(Path.Combine(root,"admin.json"));
    Check(!password.Verify("anything"),"unconfigured bypass");Reject(()=>password.Initialize("short"),"short password accepted");
    password.Initialize("Тестовый-пароль-123");Check(password.Verify("Тестовый-пароль-123")&&!password.Verify("wrong"),"password verification");
    Check(!File.ReadAllText(Path.Combine(root,"admin.json")).Contains("Тестовый"),"plaintext password stored");
    Reject(()=>password.Initialize("replacement-password"),"reinitialize bypass");
    Reject(()=>password.Change("wrong","new-password-123"),"bad old password accepted");
    password.Change("Тестовый-пароль-123","new-password-123");Check(password.Verify("new-password-123")&&!password.Verify("Тестовый-пароль-123"),"password change");
    File.WriteAllText(Path.Combine(root,"admin.json"),"{\"Version\":1,\"Algorithm\":\"PBKDF2-HMAC-SHA256\",\"Iterations\":1}");
    Reject(()=>password.Verify("anything"),"corrupt password bypass");Console.WriteLine("PASS password: PBKDF2, Unicode, wrong password, first-run protection, change, corruption");
    var now=DateTimeOffset.Now;
    byte[] Message(string extra)=>Encoding.UTF8.GetBytes("{\"type\":\"telemetry\",\"version\":1,\"name\":\"Принтер Ж\",\"state\":\"ok\",\"printed\":\"420\",\"total\":\"2113\",\"extra\":"+extra+"}");
    var unknown=Telemetry.Parse(Message("{\"alarm\":\"\"}"),now);
    Check(!unknown.ErrorsKnownEmpty,"legacy empty error incorrectly considered healthy");
    var clear=Telemetry.Parse(Message("{\"alarm\":\"\",\"alarmRead\":true}"),now);Check(clear.ErrorsKnownEmpty,"confirmed empty list lost");
    var error=Telemetry.Parse(Message("{\"alarm\":\"E4.2: Alarm\"}"),now);Check(error.Alarm!=""&&error.Printed==420&&error.Progress>0.19,"telemetry parse");
    Reject(()=>Telemetry.Parse(Encoding.UTF8.GetBytes("{\"type\":\"telemetry\",\"version\":\"bad\"}"),now),"bad version accepted");
    Console.WriteLine("PASS telemetry: actual legacy schema, Unicode, confirmed/unknown error states, progress, malformed version");
    var tracker=new AlarmTracker();var transitions=new List<AlarmChange>();tracker.Changed+=transitions.Add;
    tracker.Observe("1/2:E4.2: Cylinder Alarm",false,now);
    var firstId=tracker.Active.Single().Id;
    tracker.AcknowledgeAll(now);Check(!tracker.NeedsAttention,"acknowledgement failed");
    tracker.Observe("2/2:E4.2: Cylinder Alarm",false,now.AddSeconds(1));
    Check(tracker.Active.Single().Id==firstId&&!tracker.NeedsAttention,"rotation rearmed acknowledged error");
    tracker.Observe("1/2:E6.4: Other Alarm",false,now.AddSeconds(2));
    Check(tracker.Active.Count==2&&tracker.NeedsAttention,"additional alarm did not rearm");
    tracker.Observe("",false,now.AddSeconds(3));Check(tracker.Active.Count==2,"unknown empty read cleared errors");
    tracker.AcknowledgeAll(now);tracker.Observe("",true,now.AddSeconds(4));
    Check(tracker.Active.Count==0&&!tracker.NeedsAttention,"confirmed clear failed");
    tracker.Observe("1/1:E4.2: Cylinder Alarm",false,now.AddSeconds(5));
    Check(tracker.NeedsAttention&&tracker.Active.Single().Id!=firstId,"reappearing error stayed acknowledged");
    Check(transitions.Count(e=>e.Kind=="Появление")==3&&transitions.Count(e=>e.Kind=="Снятие")==2,"lifecycle history wrong");
    var journal=new AlarmHistoryStore(Path.Combine(root,"history.json"));
    journal.Save(transitions.Select(e=>new AlarmHistoryEntry(config.Id,config.Name,e)));
    Check(journal.Load().SequenceEqual(transitions.Select(e=>new AlarmHistoryEntry(config.Id,config.Name,e))),"history restart roundtrip");
    journal.Save(Enumerable.Range(0,2100).Select(i=>new AlarmHistoryEntry(config.Id,config.Name,new(now.AddSeconds(i),"Появление",Guid.NewGuid(),"Тест"))));
    Check(journal.Load().Count==2000&&journal.Load()[0].Change.At==now.AddSeconds(100),"history retention failed");
    store.Save(store.Load() with{AlarmSoundFile="C:\\sounds\\Ошибка.wav"});
    Check(store.Load().AlarmSoundFile.EndsWith("Ошибка.wav"),"audio settings lost");
    Console.WriteLine("PASS alarms: independent acknowledgement, rotation, new/reappearing errors, unknown reads, confirmed clear, persistent bounded history, audio settings");
    var clock=new ManualClock();var watch=new LayerWatchdog(clock);
    var sample=clear with{Printed=100,Total=200,FinishKind="ESTIMATE",File="job/0100.tif",Mode="MainAuto"};
    void AdvanceSamples(int seconds,Telemetry value){for(int i=0;i<seconds;i++){clock.Advance(1);watch.Observe(value);watch.Tick(true);}}
    watch.Observe(sample);AdvanceSamples(59,sample);Check(!watch.IsStalled&&watch.Seconds==59,"alarm before 60 seconds");
    AdvanceSamples(1,sample with{Mode="Pause"});Check(watch.IsStalled,"pause should also trigger at 60 seconds");
    watch.Observe(sample with{Printed=101});Check(!watch.IsStalled&&watch.Seconds==0,"layer advance did not clear");
    AdvanceSamples(60,sample with{Printed=101});Check(watch.IsStalled,"second stop did not rearm");
    watch.Tick(false);Check(!watch.IsStalled&&!watch.IsTracking,"disconnection left local stall active");
    watch.Observe(sample);clock.Advance(6);watch.Tick(true);Check(!watch.IsTracking,"stale telemetry not suspended");
    watch.Observe(sample);Check(watch.Seconds==0,"reconnect reused old timer");
    watch.Observe(sample with{ReadSucceeded=false});Check(!watch.IsTracking,"read failure not suspended");
    watch.Observe(sample with{Printed=200});Check(!watch.IsTracking,"completed counter armed");
    watch.Observe(sample with{FinishKind="FINISHED"});Check(!watch.IsTracking,"finished job armed");
    watch.Observe(sample with{Printed=null});Check(!watch.IsTracking,"missing counter armed");
    watch.Observe(sample);AdvanceSamples(59,sample);watch.Observe(sample with{File="new-job/0100.tif"});Check(watch.Seconds==0,"new file did not reset");
    clock.Advance(10);watch.Observe(sample);Check(watch.Seconds==0,"sample gap reused old timer");
    Console.WriteLine("PASS layer watchdog: exact 60-second threshold, pause included, layer advance, rearm, disconnect, stale/read failure, completed/missing fields, new job, sample gaps");
    var recorder=new RecorderSettings{Enabled=true,Host="192.168.1.64",Username="оператор",ProtectedPassword="encrypted-placeholder"};
    Check(recorder.StreamPath(1)=="/Streaming/Channels/102"&&recorder.StreamPath(2)=="/Streaming/Channels/202","substream camera channel mapping");
    Check((recorder with{Substream=false,Channel2=4}).StreamPath(2)=="/Streaming/Channels/401","main stream channel mapping");
    var cameraUri=recorder.BuildUri(1,"p:@/#% слово");
    Check(cameraUri.Host=="192.168.1.64"&&cameraUri.Port==554&&Uri.UnescapeDataString(cameraUri.UserInfo.Split(':')[1])=="p:@/#% слово","RTSP credential escaping");
    Reject(()=> (recorder with{Host="http://bad"}).Validate(),"invalid recorder accepted");
    Reject(()=> (recorder with{Channel2=1}).Validate(),"duplicate camera channel accepted");
    Reject(()=> (recorder with{Port=0}).Validate(),"invalid RTSP port accepted");
    Reject(()=> recorder.StreamPath(3),"invalid camera slot accepted");
    var cameraConfig=config with{Cameras=recorder};store.Save(store.Load() with{Printers=[cameraConfig]});
    var retained=store.Load();store.Save(retained with{Printers=[retained.Printers[0] with{Name="Переименован"}]});
    Check(store.Load().Printers[0].Cameras==recorder,"camera settings lost on printer edit");
    Check(!File.ReadAllText(store.Path).Contains("p:@/#%"),"camera plaintext password persisted");
    Console.WriteLine("PASS camera settings: backward-compatible settings, Hikvision channel mapping, RTSP escaping, validation, edit preservation");
    var listener=new TcpListener(IPAddress.Loopback,0);listener.Start();
    int port=((IPEndPoint)listener.LocalEndpoint).Port;
    using var stop=new CancellationTokenSource(TimeSpan.FromSeconds(12));
    var delivered=new TaskCompletionSource<Telemetry>(TaskCreationOptions.RunContinuationsAsynchronously);
    var observed=AgentConnection.ObserveAsync(config with{Host="127.0.0.1",Port=port},t=>delivered.TrySetResult(t),_=>{},stop.Token);
    using(var client=await listener.AcceptTcpClientAsync(stop.Token))
    {
        var payload=Message("{\"alarm\":\"\"}");var marker=Encoding.UTF8.GetBytes("Ж");int split=payload.AsSpan().IndexOf(marker)+1;
        Check(split>0,"fixture marker missing");
        await client.GetStream().WriteAsync(payload.AsMemory(0,split),stop.Token);
        await Task.Delay(30,stop.Token);
        await client.GetStream().WriteAsync(payload.AsMemory(split),stop.Token);
        await client.GetStream().WriteAsync(new byte[]{10},stop.Token);
        var actual=await delivered.Task.WaitAsync(stop.Token);Check(actual.Name=="Принтер Ж","fragmented UTF8 damaged");
    }
    stop.Cancel();await observed;listener.Stop();
    Console.WriteLine("PASS network: real loopback TCP stream, fragmented UTF-8, cancellation");
}
finally{Directory.Delete(root,true);}

sealed class ManualClock : TimeProvider
{
    private long seconds;
    public override long TimestampFrequency=>1;
    public override long GetTimestamp()=>seconds;
    public void Advance(int amount)=>seconds+=amount;
}
